var num=9;
for(i=1;i<=20;i++){
    console.log(`9*${i}=${9*i}`);
}