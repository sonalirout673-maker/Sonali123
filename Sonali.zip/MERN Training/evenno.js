
// for(let i=1;i<=49;i++){
//  if(i%2===0)
//     console.log(i)
// }


for(let i=2 ;i<=48; i+=2)
{
    console.log(i)
}