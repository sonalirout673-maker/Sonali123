// console.log(a)
// var a=15
// console.log(a)
// //for(a=5;a<=9;a++){
//     //console.log(a)
// //}



// Set your secret password
// const correctPassword = "mySecret123";

// // Ask user for password
// const userInput = ("Enter the password:");

// // Check if the password is correct
// if (userInput === correctPassword) {
//   alert(" Access granted. Welcome!");
//   // You can run more protected code here
// } else {
//   alert(" Incorrect password. Access denied.");
// }


//Password stored in code
const correctPassword = "mySecret123";
const userPassword = "mySecret123"; 
if (userPassword === correctPassword) {
  console.log(" Access granted.");
} else {
  console.log(" Access denied.");
}






//password program


// const correctPassword = "mySecret123";

// const userPassword = "mySecret123"; 


// if (userPassword === correctPassword) {
//   console.log(" Access granted.");
// } else {
//   console.log(" Access denied.");
// }

