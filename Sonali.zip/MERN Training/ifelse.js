// let number=20;
// if(number>30){
//     console.log("the number is positive");
// }else{
//     console.log("the number is negative");
// }


// let age=18;
// if(age>=18){
//     console.log("you are an adult");
// }else{
//     console.log("you are minor");
// }





// let marks = 75;

// if (marks >= 90) {
//   console.log("Grade: A+");
// } else if (marks >= 80) {
//   console.log("Grade: A");
// } else if (marks >= 70) {
//   console.log("Grade: B");
// } else if (marks >= 60) {
//   console.log("Grade: C");
// } else {
//   console.log("Grade: Fail");
// }


let temperature = 32;

if (temperature > 35) {
  console.log("It's too hot outside!");
} else if (temperature >= 25 && temperature <= 35) {
  console.log("The weather is warm.");
} else if (temperature >= 15 && temperature < 25) {
  console.log("The weather is pleasant.");
} else {
  console.log("It's cold outside!");
}