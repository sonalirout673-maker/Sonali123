// const random={id:"x7g8",name:"sonali",roll:72,class:3}
// random.id="e6e3buf8r48"
// random.name="jsueiaydr7w4fhe"
// random.college="nit"
// console.log(random)
// const randomtwo={...random,new:"kdjshoivjdm",newtwo:"hsbcfuoshnk "}
// console.log(randomtwo)
// const {newtwo,id,name}=randomtwo;
// console.log(newtwo,id,name)


// const user={id:42,name:"sonali",email:"sonali@gmail.com"};
// const{id,name}=user;
// console.log(id);





// function xyz(a,b,...rest){
// console.log(a)
// console.log(b)
// console.log(rest)
// }
// xyz(2,3,4,5,6,7)



function greet(name="sonali",message="welcome"){
    console.log(`${message},${name}`)
}
greet()
greet("sony","hello")
greet("bob")

