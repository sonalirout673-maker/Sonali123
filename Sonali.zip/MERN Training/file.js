import { addition, subtract,multiply, divide } from `/que.js;`;
console.log("addition",add(5,10));
console.log("substract",sub(5,10));
console.log("multiplication",mul(5,10));
console.log("division",div(5,10));