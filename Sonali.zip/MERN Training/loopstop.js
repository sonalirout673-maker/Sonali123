// for(i=0;i<=10;i++){
//     //if(i===5)
//        // break;
//     //if(i!==6)
//     if(i===6)
//         continue;
//     console.log(i);
// }

for(i=0;i<=10;i++){
    // if(i===5)
    //    break;
    // if(i!==6)
    if(i==6)
        continue;
    console.log(i);
}