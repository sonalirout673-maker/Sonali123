//factorial of num
let num = 5;
let fact = 1;
for(let i = 1; i <= num; i++){
    fact *= i;
    
} 
console.log("factorial of" , +num+  " is: " + fact);