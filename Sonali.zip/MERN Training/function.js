// function xyz(name){
// console.log("hello" + name)
// }
// xyz("sonali");

// odd and even

// let a=56
// if(a%2==0){
//     console.log("Even")
// }
// else{
//     console.log("odd")
// }



// function checkoddeven(number){
//     if(number%2===0){
//         console.log("even")
// }
// }
// else{
//     console.log("odd")
    
// }
// checkoddeven(56)



// function xyz(a,b,c){
//     if(a>=b && a>=c){
//         console.log("A is greatest")
//     }
//     else if(b>=a && b>=c){
//         console.log("B is greatest")
//     }
//     else{
//         console.log("C is greatest")
//     }
// }
// xyz(45,78,99)


// function expressin


// const xyz = function(name){
//     console.log(name)
// }
// xyz("Sonali")



// declearation of function


// function print(x){
//     console.log(x)
// }
// print("Sonali")



// const checkoddeven =function(num){
//     if(num%2===0){
//        console.log(num + "even");
//    }
// }else{
//     console.log(num + "odd");
// }
// checkoddeven(45)


// function delearation

// function calculator(a,b,operator){
//     if(operator ==="+"){
//         console.log("calculator:",a+b);
//     }else if(operator ==="-"){
//         console.log("calculator:",a-b);
//     }else if(operator ==="*"){
//         console.log("calculator:",a*b);
//     }else if(operator ==="/"){
//         console.log("calculator:",a/b);
//     } 
// }
// calculator(3,4,"+");
//     calculator(4,5,"-");
//     calculator(6,7,"*");
//     calculator(7,8,"/");


// switch

 const calculator=function(a,b,operator){
    constswitch(operator)
   case(operator==="+")
    case(operator==="-")
    case(operator==="*")
   case(operator==="/")
   case(operator==="%")
}




